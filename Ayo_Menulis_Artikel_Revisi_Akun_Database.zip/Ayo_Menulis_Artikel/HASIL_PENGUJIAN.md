# Validasi pembaruan

Lulus: kompilasi Python; 5 tes backend dan satu rangkaian tes tampilan.

- 105 pertanyaan berhasil pada satu akun.
- Akun, absensi, progres, nilai kuis, artikel, refleksi dan brainstorming dibuat tanpa sesi guru, lalu dibaca dari proses Python baru dengan database SQLite yang sama.
- Duplikasi username ditolak dan riwayat antar siswa terpisah.
- Token Ingat saya disimpan sebagai hash, autentikasi token valid berhasil, token palsu/kedaluwarsa ditolak dan logout mencabut token.
- Konversi SQL SQLite ke PostgreSQL untuk insert idempotent dan ID otomatis diuji.
- Semua halaman siswa serta keenam kategori dasbor guru terbuka tanpa exception dengan Streamlit AppTest.
- Protokol komponen browser untuk baca/simpan/baca kembali/hapus diuji dengan simulasi JavaScript.

Belum diuji: koneksi Supabase/PostgreSQL live karena tidak ada kredensial proyek; penyimpanan browser di situs Streamlit pengguna; API AI sungguhan dan uji beban. Setelah DATABASE_URL diisi, wajib uji akun dan hasil setelah Reboot serta buka ulang browser. Simulasi komponen bukan pengganti uji browser nyata.
