# Pembaruan Ayo Menulis Artikel

## Hasil perubahan

- Jumlah interaksi akun tidak dibatasi. Nilai kuis tetap maksimal 100.
- Dukungan PostgreSQL untuk seluruh akun, absensi, progres, kuis, artikel, refleksi, percakapan, brainstorming, dan penilaian guru.
- Dasbor memiliki Daftar siswa, termasuk siswa yang baru mendaftar dan belum mengirim tugas.
- Ingat saya menyimpan akses selama 30 hari pada browser/perangkat yang sama. Siswa kembali masuk otomatis; keluar akun mencabut akses perangkat tersebut. Password tidak disimpan di browser oleh aplikasi; token acak disimpan di browser dan hash token disimpan di database. Token ini tetap merupakan akses sensitif. Gunakan perangkat pribadi. Menghapus data browser atau berpindah alamat web memerlukan login lagi.

## Penting: aktifkan database online

Mengunggah ZIP saja TIDAK mengaktifkan penyimpanan permanen. Versi lama memakai SQLite di server Streamlit. File lokal Community Cloud tidak dijamin bertahan. Login guru tidak mengendalikan penyimpanan siswa; data dicatat saat siswa melakukan aktivitas.

Pilihan yang didukung: PostgreSQL, misalnya proyek Supabase terpisah khusus tutor ini.

1. Buat akun di https://supabase.com dan buat proyek khusus tutor.
2. Simpan password database proyek secara pribadi.
3. Pada proyek, klik Connect. Pilih Session pooler (IPv4, port 5432), lalu salin connection string.
4. Ganti placeholder password dengan password database. Jika password memuat karakter khusus, encode bagian password untuk URL. Jangan mengubah hostname, username proyek, atau nama database.
5. Di Streamlit: My apps → menu aplikasi → Settings → Secrets. Pertahankan TEACHER_PASSWORD dan API key yang sudah ada. Tambahkan DATABASE_URL sesuai contoh di bawah.
6. Simpan Secrets. Setelah seluruh file pembaruan diunggah, aplikasi membuat tabel otomatis. Gunakan koneksi server sebagai pemilik proyek (postgres), bukan key anon atau akun siswa. RLS diaktifkan tanpa kebijakan akses publik: akses database dilakukan oleh server.
7. Jika koneksi gagal, aplikasi berhenti dengan pesan aman; tidak diam-diam beralih ke database kosong.
8. Setelah terhubung, peringatan Mode uji lokal hilang. Uji dengan dua akun siswa, kuis dan artikel/refleksi, lalu logout semua akun dan buka dasbor guru. Periksa semua hasil. Ulangi setelah Reboot aplikasi. Database online tetap memerlukan layanan aktif dan pencadangan sesuai fasilitas penyedianya.

Contoh Secrets (placeholder, bukan kredensial yang siap dipakai):

```toml
TEACHER_PASSWORD = "PASSWORD_GURU_MILIKMU"
DATABASE_URL = "postgresql://USERNAME_DARI_CONNECT:PASSWORD_DATABASE@HOST_DARI_CONNECT:5432/postgres"
```

Jangan unggah Secrets, password, connection string asli, atau file data siswa ke GitHub publik. API AI tetap opsional dan mengikuti saldo/batas penyedia meskipun jumlah interaksi akun tidak dibatasi.

## File untuk GitHub

Letakkan di halaman utama proyek:
app.py, core.py, storage.py, remembered_login.py, requirements.txt, quiz.json.

Pertahankan folder database yang berisi semua materi. Tambahkan folder login_component berisi index.html.

Jika tombol unggah hanya menerima file: Create new file dengan nama login_component/index.html, kemudian salin isi file index.html dari ZIP. Empat file utama baru/diubah dapat diunggah biasa. Jangan menaruh index.html di dalam database.

Tidak perlu mengubah nama proyek atau membuat aplikasi Streamlit baru. Python 3.12.

## Data lama

ZIP dari GitHub tidak membawa data SQLite yang dibuat saat aplikasi berjalan. Jangan menganggap data lama otomatis ikut pindah.

Jika masih ada cadangan tutor.sqlite3, migrate_sqlite.py dapat memindahkan akun dan seluruh hasil belajar ke database online KOSONG. Skrip menggunakan environment DATABASE_URL, membaca SQLite dalam mode read-only, tidak menimpa tujuan yang sudah berisi data, dan menjalankan penyalinan dalam satu transaksi. Token login lama tidak dipindahkan; siswa login kembali. Jika belum tahu caranya, simpan cadangannya dan minta bantuan sebelum mengganti penyimpanan.

Data yang sudah hilang dari server dan tidak memiliki cadangan tidak dapat dipulihkan dari ZIP kode.

## Batas fitur

Ingat saya memakai komponen browser lokal yang disertakan dalam paket. Tidak menyimpan daftar semua akun siswa untuk dipilih pengunjung. Jika browser memblokir penyimpanan, masuk manual tetap tersedia. Login guru tetap memakai password dan sesi biasa. Aplikasi ini belum menjalani audit keamanan produksi atau uji beban kelas besar.

Sumber teknis:
https://docs.streamlit.io/develop/concepts/connections/connecting-to-data
https://supabase.com/docs/guides/database/connecting-to-postgres
https://www.psycopg.org/psycopg3/docs/advanced/rows.html
https://docs.streamlit.io/develop/concepts/custom-components/components-v1/intro
