import os,tempfile,unittest
from pathlib import Path
from streamlit.testing.v1 import AppTest
import core
class UI(unittest.TestCase):
 def test_pages_registration_teacher(self):
  with tempfile.TemporaryDirectory() as tmp:
   os.environ['TUTOR_DB_PATH']=str(Path(tmp)/'db.sqlite3'); os.environ['TEACHER_PASSWORD']='private-test'
   core.DB=Path(os.environ['TUTOR_DB_PATH'])
   at=AppTest.from_file('app.py').run()
   self.assertFalse(at.exception)
   at.sidebar.radio[0].set_value('Akun siswa').run()
   # Register directly then set identity, component is tested separately.
   user=core.register('uiuser','Siswa UI','XII-1','password123')
   at.session_state.user=user
   for page in ['Beranda','Materi pembelajaran','Latihan / kuis','Evaluasi & refleksi','Umpan balik AI','Tanya jawab AI Tutor','Brainstorming & kerangka','Panduan pemakaian']:
    at.sidebar.radio[0].set_value(page).run(); self.assertFalse(at.exception,page)
   at.sidebar.radio[0].set_value('Dasbor guru').run()
   at.session_state.teacher=True; at.run()
   for tab in ['Daftar siswa','Absensi','Kemajuan materi','Kuis','Artikel & penilaian','Interaksi tutor']:
    at.selectbox[0].set_value(tab).run(); self.assertFalse(at.exception,tab)
if __name__=='__main__': unittest.main()
