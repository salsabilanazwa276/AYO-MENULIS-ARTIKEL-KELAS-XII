import unittest, tempfile, os, subprocess, sys, json
from pathlib import Path
import core
class PersistenceTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); core.configure(''); core.DB=Path(self.tmp.name)/'tutor.sqlite3'; core.init()
  self.u=core.register('siswa1','Siswa Satu','XII-1','password123')
 def tearDown(self): self.tmp.cleanup()
 def test_restart_all_records_without_teacher(self):
  uid=self.u['id']; core.attend(uid); core.mark(uid,'Materi','done',True)
  answers={q['id']:q['answer'] for q in core.quiz_questions()}; core.save_quiz(uid,'attempt1',answers)
  core.submit(uid,'Artikel','kata '*500,'Sumber satu\nSumber dua','Kesulitan menyusun tesis')
  core.brainstorm(uid,{'topic':'sampah plastik'})
  env={**os.environ,'TUTOR_DB_PATH':str(core.DB)}
  script="import core,json; core.init(); u=core.authenticate('siswa1','password123'); print(json.dumps([len(core.students()),len(core.report('attendance')),len(core.report('progress')),len(core.report('quizzes')),len(core.submissions()),len(core.brainstorm_history(u['id']))]))"
  result=subprocess.check_output([sys.executable,'-c',script],env=env,text=True)
  self.assertEqual(json.loads(result),[1,1,1,1,1,1])
 def test_over_100(self):
  for i in range(105): core.ask(self.u['id'],'chat','apa itu teks artikel')
  self.assertEqual(core.used(self.u['id']),105)
 def test_remember_revoke_and_expiry(self):
  token=core.remember(self.u['id']); self.assertEqual(core.remembered_user(token)['id'],self.u['id'])
  with core.conn() as c:
   row=c.execute('SELECT * FROM remembered_sessions').fetchone()
   self.assertNotEqual(row['token_hash'],token)
  self.assertIsNone(core.remembered_user('x'*43)); core.forget(token); self.assertIsNone(core.remembered_user(token))
  token=core.remember(self.u['id'],days=-1); self.assertIsNone(core.remembered_user(token))
 def test_isolation_and_duplicate(self):
  other=core.register('siswa2','Dua','XII-2','password123')
  core.ask(self.u['id'],'chat','apa itu teks artikel')
  self.assertEqual(core.history(other['id'],'chat'),[])
  with self.assertRaises(ValueError): core.register('siswa1','Lain','XII-2','password123')
 def test_sql_translation(self):
  from storage import postgres_sql
  self.assertEqual(postgres_sql('INSERT OR IGNORE INTO attendance VALUES(?,?,?)'),'INSERT INTO attendance VALUES(%s,%s,%s) ON CONFLICT DO NOTHING')
  self.assertIn('BIGSERIAL',postgres_sql('id INTEGER PRIMARY KEY AUTOINCREMENT'))
if __name__=='__main__': unittest.main()
