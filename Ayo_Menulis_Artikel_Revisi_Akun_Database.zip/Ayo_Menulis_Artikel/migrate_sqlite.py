"""Copy a preserved SQLite backup into an EMPTY PostgreSQL database.
Run: DATABASE_URL=... python migrate_sqlite.py /private/path/tutor.sqlite3
Never commit the backup or connection string to GitHub.
"""
import os, sys, sqlite3
from pathlib import Path
import core

def migrate(source):
    url=os.environ.get('DATABASE_URL','')
    if not url: raise ValueError('Isi environment DATABASE_URL terlebih dahulu.')
    if not Path(source).is_file(): raise ValueError('File cadangan tidak ditemukan.')
    core.configure(url); core.init()
    tables=['users','attendance','progress','messages','calls','quizzes','brainstorms','submissions']
    src=sqlite3.connect(f'file:{Path(source).resolve()}?mode=ro',uri=True); src.row_factory=sqlite3.Row
    try:
        existing={r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        with core.conn() as dst:
            dst.execute('SELECT pg_advisory_xact_lock(842197320)')
            for table in tables:
                if dst.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]:
                    raise ValueError('Database tujuan harus kosong. Tidak ada data lama yang ditimpa.')
            for table in tables:
                if table not in existing or table=='calls': continue
                rows=src.execute(f'SELECT * FROM {table}').fetchall()
                for row in rows:
                    columns=list(row.keys())
                    dst.execute(f'INSERT INTO {table} ({",".join(columns)}) VALUES({",".join("?" for _ in columns)})',tuple(row))
            dst.execute("SELECT setval(pg_get_serial_sequence('messages','id'),COALESCE(MAX(id),1),MAX(id) IS NOT NULL) FROM messages")
    finally: src.close()
if __name__=='__main__':
    try:
        if len(sys.argv)!=2: raise ValueError('Berikan lokasi file tutor.sqlite3.')
        migrate(sys.argv[1]); print('Migrasi selesai. Akun, hasil belajar, dan riwayat tersalin.')
    except ValueError as e: print(str(e)); sys.exit(1)
    except Exception: print('Migrasi gagal. Periksa koneksi dan cadangan; rincian koneksi tidak ditampilkan.'); sys.exit(1)
